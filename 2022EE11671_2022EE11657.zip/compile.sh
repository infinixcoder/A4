#!/bin/bash
g++ -std=c++11 -o solver solver.cpp