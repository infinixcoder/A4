#!/bin/bash
./solver $1 $2